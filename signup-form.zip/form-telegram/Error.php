<!doctype html>
<html>
 
<head>
  <title>loading...</title>
</head>

<body>
<br>
error Recommencer svp
<META HTTP-EQUIV='Refresh' Content=2;URL='./'>
 
</body>
</html>