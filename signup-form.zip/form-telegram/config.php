<?php

$METRI_TOKEN = "https://api.telegram.org/bot1218896856:AAGQbLKAnnFz_1nn4DV-VducfFjlfgl";

$chat_id = "-43453429";



?>